package com.prueba.arquitecturas_android.model

interface CouponsRepository {

    fun getCouponsAPI()
}